# About this Project
- This project is just an experiment of Code of Conducts and License
- Remember outside of our Terms, GitHub Community Guidelines, Code of Conduct, Terms of Services also counts.
- 
